# image-classification-python-scikit-learn

Building an image classifier with Python and Scikit learn !

[![Watch the video](https://img.youtube.com/vi/il8dMDlXrIE/0.jpg)](https://www.youtube.com/watch?v=il8dMDlXrIE)
